package internal;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class UpdatePRODUCTS extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Initialize the DB
		
				Connection con;
				String id = request.getParameter("prod_id");
				try {
					
					
					con = DatabaseConnection.initializeDatabase();
					
					
					
					String sql = "update product set cat_name=?, prod_name=?, quantity=?, price=? where prod_id='"+id+"'";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					
					
					st.setString(1, (request.getParameter("cat_name")));
					st.setString(2, (request.getParameter("prod_name")));
					st.setString(3, (request.getParameter("quantity")));
					st.setString(4, (request.getParameter("price")));
					
					

					
					
					//Execute the insert command using executeUpdate() to make changes in the database
					st.executeUpdate();
					
					//Close all DB connections
			
					
					//Get the PrintWriter pointer/object to display the successful result message
					PrintWriter out = response.getWriter();
					 out.println("<meta http-equiv='refresh' content='1; URL=SearchUser.html'>");
					 out.println("<p style ='color:red;'> Records Successfully Updated!! </p>");
					
					
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
	}


