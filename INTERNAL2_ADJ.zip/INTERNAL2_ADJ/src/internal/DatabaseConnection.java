/**
 * 
 */
package internal;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author MOSESANE JULIUS
 *
 */
public class DatabaseConnection {
	protected static Connection initializeDatabase() throws ClassNotFoundException, SQLException
	{
		String driver = "com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/BOTHO";
		//String dBName = "BOTHO";
		String username = "sephapo";
		String password = "1234";
		
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url, username, password);
		
		return con;
		
	}


}

