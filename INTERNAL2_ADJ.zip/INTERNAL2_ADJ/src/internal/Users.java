package internal;

import java.io.IOException;


import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Users extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Initialize the DB
		Connection con;
		try {
			
			
			con = DatabaseConnection.initializeDatabase();
			
			
			
			String sql = "insert into users values(?, ?, ?, ?)";
			
			PreparedStatement st = con.prepareStatement(sql);
			
			
			st.setString(1, (request.getParameter("id")));
			st.setString(2, (request.getParameter("name")));
			st.setString(3, (request.getParameter("usertype")));
			st.setString(4, (request.getParameter("password")));
			

			
			
			//Execute the insert command using executeUpdate() to make changes in the database
			st.executeUpdate();
			
			//Close all DB connections
			
		
			con.close();
			
			//Get the PrintWriter pointer/object to display the successful result message
			PrintWriter out = response.getWriter();
			  out.println("<meta http-equiv='refresh' content='1; URL=AddUser.html'>");
			 out.println("<p style ='color:red;'> Records Successfully Inserted! </p>");
			
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
