
package internal;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginForm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out = response.getWriter();
		Connection con;
		
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		String usertype = request.getParameter("usertype");

		try {
			
			con = DatabaseConnection.initializeDatabase();
	
 
		PreparedStatement ps = con.prepareStatement("select name,password, usertype from users where name=? and password=? and usertype=?");
		ps.setString(1, name);
		ps.setString(2, password);
		ps.setString(3,usertype);
 
		ResultSet rs = ps.executeQuery();
 
		if (rs.next()) {
				 
			 HttpSession session = request.getSession(true);
			 session.setAttribute("name", name);
			 session.setMaxInactiveInterval(30);
			 response.sendRedirect("Admin_Pannel.html"); 
			 
			return;
		}
		else {
		
		
				
				  out.println("<meta http-equiv='refresh' content='1; URL=User_Login.html'>");
				 out.println("<p style ='color:red;'> Incorrectname or Password ! </p>");
				 
					
				
				 
			 
		}
		
		return;
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
	}

	}


